package com.pelicanx.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Intent
import android.net.Uri
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 20)
    private val panel = Color.rgb(18, 27, 39)
    private val mint = Color.rgb(0, 214, 163)
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addBinderReceivedListener { runOnUiThread { updateShizuku() } }
        Shizuku.addBinderDeadListener { runOnUiThread { status.text = "Shizuku: desconectado" } }
        buildUi()
        updateShizuku()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "PELICAN X"
            textSize = 30f
            setTextColor(mint)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "MOBILE TOOLKIT  •  V1.0"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(14, 16, 14, 16)
            setBackgroundColor(panel)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24; bottomMargin = 16 })
        addSection(root, "SENSIBILIDADE")
        val seek = SeekBar(this).apply { max = 200; progress = 100 }
        root.addView(seek)
        val sens = TextView(this).apply { text = "Valor: 100"; setTextColor(Color.WHITE); textSize = 15f }
        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) { sens.text = "Valor: $value" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sens)
        addSection(root, "DPI")
        val dpiInput = EditText(this).apply {
            hint = "Digite o DPI atual"
            inputType = 2
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(panel)
        }
        root.addView(dpiInput)
        val dpiResult = TextView(this).apply { setTextColor(mint); textSize = 14f; setPadding(0, 8, 0, 8) }
        root.addView(makeButton("CALCULAR ESCALA") {
            val n = dpiInput.text.toString().toIntOrNull()
            dpiResult.text = if (n != null && n > 0) "Referência: ${n} DPI. Ajuste com cuidado nas configurações do Android." else "Informe um DPI válido."
        })
        root.addView(dpiResult)
        addSection(root, "TREINO")
        root.addView(info("Ferramentas locais para treino: ajuste sua sensibilidade, pratique o arrasto e personalize seu HUD. Não altera o Free Fire nem automatiza disparos ou mira."))
        root.addView(makeButton("ABRIR CONFIGURAÇÕES DE TELA") {
            startActivity(Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS))
        })
        root.addView(makeButton("VERIFICAR SHIZUKU") { updateShizuku() })
        root.addView(makeButton("GUIA SHIZUKU") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/")))
        })
        val foot = TextView(this).apply {
            text = "PELICAN X • Ferramentas de treino e personalização"
            setTextColor(Color.GRAY); textSize = 10f; gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(foot)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addSection(root: LinearLayout, label: String) {
        root.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(mint)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 20, 0, 8)
        })
    }

    private fun info(message: String) = TextView(this).apply {
        text = message; textSize = 13f; setTextColor(Color.LTGRAY)
        setPadding(14, 14, 14, 14); setBackgroundColor(panel)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(28, 54, 66))
        setOnClickListener { action() }
    }

    private fun updateShizuku() {
        val connected = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        status.text = if (connected) "Shizuku: serviço detectado" else "Shizuku: não conectado. Inicie o serviço no app Shizuku e tente novamente."
    }
}
