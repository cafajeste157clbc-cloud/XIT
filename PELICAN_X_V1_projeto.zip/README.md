# PELICAN X V1

Projeto Android Kotlin, sem root, com painel de sensibilidade, calculadora de referência DPI e detecção básica do serviço Shizuku.

## Compilar no Android Studio
1. Abra a pasta `PELICAN_X_V1` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Se necessário, instale Android SDK Platform 35 e JDK 17.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Shizuku
Instale e inicie o Shizuku separadamente. Este projeto apenas detecta se o serviço está ativo; não executa comandos privilegiados.

## Limites
O app não injeta código no Free Fire, não lê memória do jogo e não oferece ESP, aimbot ou aimlock. Os controles são ferramentas locais de treino/personalização.
